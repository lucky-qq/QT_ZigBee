#include <ioCC2530.h>
#include <string.h>

typedef union 
{ unsigned int i;
  float f;
} value;

enum {TEMP,HUMI};

#define uint unsigned int
#define uchar unsigned char

#define	DATA   	P0_0
#define	SCK   	P0_1
                            //adr  command  r/w
#define STATUS_REG_W 0x06   //000   0011    0
#define STATUS_REG_R 0x07   //000   0011    1
#define MEASURE_TEMP 0x03   //000   0001    1
#define MEASURE_HUMI 0x05   //000   0010    1
#define RESET        0x1e   //000   1111    0

#define noACK 0
#define ACK   1

#define DATA_OUT P0DIR|=0x01
#define DATA_IN  {P0DIR&=~0x01 ;P0INP&=~0x01;}
#define SCK_OUT P0DIR|=0x02
#define SEL P0SEL&=~0x03 



void delay_us(uint s) ;
void  delay_2s();
void init_IO();
char s_read_byte(unsigned char ack);
char s_write_byte(uchar value);
void s_transstart(void);
void s_connectionreset(void);
char s_softreset(void);
char s_read_statusreg(unsigned char *p_value, unsigned char *p_checksum);
char s_write_statusreg(unsigned char *p_value);
char s_measure(unsigned char *p_value, unsigned char *p_checksum, unsigned char mode);
//char s_measure(unsigned int *p_value, unsigned char *p_checksum, unsigned char mode);
//void calc_sth11(float *p_humidity ,float *p_temperature);
void calc_sth11(uint *p_humidity ,uint *p_temperature);

#ifdef UART_DEBUG
void initUARTtest(void);
void UartTX_Send_String(unsigned char *Data,int len);
#endif
void ui16toa(uint i,unsigned char *a);
uchar len_intchar(unsigned char *a , uint len);
void uart_temp_humi(uint temp_1,uint humi_1);