 #include "sht10.h"

unsigned char Txdata[60]="ok\n";

void init_IO()
{
  SCK_OUT;
  DATA_OUT;
  SEL;
  DATA = 1;
}

void delay_us(uint s) 
{
  while (s--)
  {
      asm("NOP");
      asm("NOP");
      asm("NOP");
  }
}

char s_write_byte(uchar value)
//----------------------------------------------------------------------------------
// writes a byte on the Sensibus and checks the acknowledge 
{ 
  uchar i,error=0;  
  DATA_OUT;
  SCK_OUT;      //���w
  for (i=0x80;i>0;i/=2)             //shift bit for masking
  { if (i & value) DATA=1;          //masking value with i , write to SENSI-BUS
    else DATA=0;                        
    SCK=1;                          //clk for SENSI-BUS
   // _nop_();_nop_();_nop_();        //pulswith approx. 5 us  	
    delay_us(5);
    SCK=0;
    delay_us(1);
  }
 // DATA=0;                           //release DATA-line
  DATA_IN;
  SCK=1;                            //clk #9 for ack 
  delay_us(1);
  error=DATA;                       //check ack (DATA will be pulled down by SHT11)
  SCK=0;  
  DATA_OUT;
  return error;                     //error=1 in case of no acknowledge
}

char s_read_byte(uchar ack)
{  
  unsigned char i,val=0;
  DATA_OUT;
  SCK_OUT;      //���w
  DATA=1;  
  DATA_IN;                         //release DATA-line
  for (i=0x80;i>0;i/=2)             //shift bit for masking
  { 
    SCK=1;                          //clk for SENSI-BUS
  //  delay_us(5);//??
    if (DATA) val=(val | i);        //read bit  
    SCK=0;  	
    delay_us(5);//??
  }
  DATA_OUT;
  DATA=!ack;                        //in case of "ack==1" pull down DATA-Line
  SCK=1;                            //clk #9 for ack
 // _nop_();_nop_();_nop_();          //pulswith approx. 5 us 
  delay_us(5);
  SCK=0;						    
  DATA=1;                           
 // DATA_IN;                          //release DATA-line
  return val;
}



//----------------------------------------------------------------------------------
void s_transstart(void)
//----------------------------------------------------------------------------------
// generates a transmission start 
//       _____         ________
// DATA:      |_______|
//           ___     ___
// SCK : ___|   |___|   |______
{  
   DATA_OUT;
   SCK_OUT;      //���w
   DATA=1; SCK=0;                   //Initial state
   //_nop_();
   delay_us(1);
   SCK=1;
  // _nop_();
   delay_us(1);
   DATA=0;
   //_nop_();
   delay_us(1);
   SCK=0;  
  // _nop_();_nop_();_nop_();
   delay_us(5);
   SCK=1;
   //_nop_();
   delay_us(1);
   DATA=1;		   
   //_nop_();
   delay_us(1);
   SCK=0;		   
}

void s_connectionreset(void)
//----------------------------------------------------------------------------------
// communication reset: DATA-line=1 and at least 9 SCK cycles followed by transstart
//       _____________________________________________________         ________
// DATA:                                                      |_______|
//          _    _    _    _    _    _    _    _    _        ___     ___
// SCK : __| |__| |__| |__| |__| |__| |__| |__| |__| |______|   |___|   |______
{  
  unsigned char i; 
  DATA_OUT;
  DATA=1; SCK=0;                    //Initial state
  for(i=0;i<9;i++)                  //9 SCK cycles
  { 
    SCK=1;
    delay_us(1);//??
    SCK=0;
    delay_us(1);//??
  }
  s_transstart();                   //transmission start
}


char s_softreset(void)
//----------------------------------------------------------------------------------
// resets the sensor by a softreset 
{ 
  unsigned char error=0;  
  s_connectionreset();              //reset communication
  error+=s_write_byte(RESET);       //send RESET-command to sensor
  return error;                     //error=1 in case of no response form the sensor
}

//----------------------------------------------------------------------------------
char s_read_statusreg(unsigned char *p_value, unsigned char *p_checksum)
//----------------------------------------------------------------------------------
// reads the status register with checksum (8-bit)
{ 
  unsigned char error=0;
  s_transstart();                   //transmission start
  error=s_write_byte(STATUS_REG_R); //send command to sensor
  *p_value=s_read_byte(ACK);        //read status register (8-bit)
  *p_checksum=s_read_byte(noACK);   //read checksum (8-bit)  
  return error;                     //error=1 in case of no response form the sensor
}

//----------------------------------------------------------------------------------
char s_write_statusreg(unsigned char *p_value)
//----------------------------------------------------------------------------------
// writes the status register with checksum (8-bit)
{ 
  unsigned char error=0;
  s_transstart();                   //transmission start
  error+=s_write_byte(STATUS_REG_W);//send command to sensor
  error+=s_write_byte(*p_value);    //send value of status register
  return error;                     //error>=1 in case of no response form the sensor
}

//----------------------------------------------------------------------------------
char s_measure(unsigned char *p_value, unsigned char *p_checksum, unsigned char mode)
//----------------------------------------------------------------------------------
// makes a measurement (humidity/temperature) with checksum
{ 
  unsigned char error1=0;
  unsigned int i;

  s_transstart();                   //transmission start
  switch(mode){                     //send command to sensor
    case TEMP	: error1+=s_write_byte(MEASURE_TEMP); break;
    case HUMI	: error1+=s_write_byte(MEASURE_HUMI); break;
    default     : break;	 
  }
  DATA_IN;
  for (i=0;i<65535;i++) {delay_us(1);if(DATA==0) break; }//wait until sensLor has finished the measurement
  if(DATA) error1+=1;                // or timeout (~2 sec.) is reached
  DATA_OUT;
  *(p_value)  =s_read_byte(ACK);    //read the first byte (MSB)
  *(p_value+1)=s_read_byte(ACK);    //read the second byte (LSB)
  *p_checksum =s_read_byte(noACK);  //read checksum
  return error1;
}

/* 
//----------------------------------------------------------------------------------
char s_measure(unsigned int *p_value, unsigned char *p_checksum, unsigned char mode)
//----------------------------------------------------------------------------------
// makes a measurement (humidity/temperature) with checksum
{ 
  unsigned char error1=0;
  uchar temp[2];
  unsigned int i,tem_num;

  s_transstart();                   //transmission start
  switch(mode){                     //send command to sensor
    case TEMP	: error1+=s_write_byte(MEASURE_TEMP); break;
    case HUMI	: error1+=s_write_byte(MEASURE_HUMI); break;
    default     : break;	 
  }
  DATA_IN;
  for (i=0;i<65535;i++) {delay_us(1);if(DATA==0) break; }//wait until sensLor has finished the measurement
  if(DATA) error1+=1;                // or timeout (~2 sec.) is reached
  DATA_OUT;
  temp[0] =s_read_byte(ACK);    //read the first byte (MSB)
  temp[1] =s_read_byte(ACK);    //read the second byte (LSB)
  ;
  tem_num = (uint)temp[0]*256 + (uint)temp[1];
  *p_value = tem_num;

  
  *p_checksum =s_read_byte(noACK);  //read checksum
  return error1;
}
*/

#ifdef UART_DEBUG
/****************************************************************
*�������� ����ʼ������1										
*��ڲ��� ����												
*�� �� ֵ ����							
*˵    �� ��57600-8-n-1						
****************************************************************/
void initUARTtest(void)
{

    CLKCONCMD &= ~0x40;              //����
    while(!(SLEEPSTA & 0x40));      //�ȴ������ȶ�
    CLKCONCMD &= ~0x47;             //TICHSPD128��Ƶ��CLKSPD����Ƶ
    SLEEPCMD |= 0x04; 		 //�رղ��õ�RC����

    PERCFG = 0x00;				//λ��1 P0��
    P0SEL = 0x3c;				//P0��������
    P0DIR &= ~0XC0;                             //P0������Ϊ����0

    U0CSR |= 0x80;				//UART��ʽ
 /*    U0GCR |= 10;				//baud_e
    U0BAUD |= 216;				//��������Ϊ57600*/
 //     U0GCR |= 8;				//baud_e
 //   U0BAUD |= 59;				//��������Ϊ9600??38400!!
    U0GCR |= 12;				//baud_e
    U0BAUD |= 216;	//��������Ϊ230400
    
 //   U0GCR |= 11;				//baud_e
 //   U0BAUD |= 216;	//��������Ϊ115200
    
    UTX0IF = 0;
}

/****************************************************************
*�������� �����ڷ����ַ�������					
*��ڲ��� : data:����									
*			len :���ݳ���							
*�� �� ֵ ����											
*˵    �� ��				
****************************************************************/
void UartTX_Send_String(unsigned char *Data,int len)
{
  int j;
  for(j=0;j<len;j++)
  {
    U0DBUF = *Data++;
    while(UTX0IF == 0);
    UTX0IF = 0;
  }
}
#endif

/****************************************************************
*�������� ��uintתchar*				
*��ڲ��� : i ԭ������									
*	    a ת���ŵ�����							
*�� �� ֵ ����											
*˵    ��   a�����Ѿ������˿ռ�		
****************************************************************/
void ui16toa(uint i,unsigned char *a)
{
  int j,len;
  uint tem;
  tem=i;
  j=0;
  for(j=0;tem/10!=0;j++)
  {
    if(tem/10!=0)
    {
      tem/=10;
    }
  }
  len=j+1;
 // a = new char[len];C++�в���?
  tem=i;
  for(j=len-1;j>=0;j--)
  {
    a[j]='0'+tem%10;
    tem=tem/10;
  }
  a[len]='\0';

}
/****************************************************************
*�������� ������������޹ص�0ȥ��			
*��ڲ��� : a ԭ����	
            i ԭ���鳤��	
*�� �� ֵ ����ȡ�����鳤��										
*˵    ��   	
****************************************************************/
uchar len_intchar(unsigned char *a , uint len)
{
  int i;

  for(i=len-1;i>=0;i--)
  {
    if(a[i] != ' ')
      break;   
  }
  return i;
  
}
/*
void uart_temp_humi(uint temp_1,uint humi_1)
{
    unsigned int len_int;
       ui16toa(temp_1,Txdata);
   //   len_int = len_intchar(Txdata , 30);
      UartTX_Send_String(Txdata,3);
     memset(Txdata,' ',30);
      strcpy(Txdata,"C\n");
      UartTX_Send_String(Txdata,strlen("C\n"));

      ui16toa(humi_1,Txdata);
    //  len_int = len_intchar(Txdata , 30);
      UartTX_Send_String(Txdata,3);
     memset(Txdata,' ',30);
      strcpy(Txdata,"RH\n");
      UartTX_Send_String(Txdata,strlen("RH\n"));
}
*/