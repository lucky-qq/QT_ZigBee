﻿
/*added by Simon*/
#define BUF_MAX   88
#define MY_PORT_NUM   0
uint8 gUartBuf[BUF_MAX];

/*************************************************************************/
/*|  1    | 1     |   2          |  2        |    1       |  1   |  80  |*/
/*-----------------------------------------------------------------------*/
/*|  type | id    |   sequence   |  shortAddr|  endpoint  |  0   | Data |*/
/*************************************************************************/
static void rxCB(uint8 port,uint8 event); 

#define TINY_ID_MAX      16
#define PHOTO_ID_MAX      1

typedef struct _AddrInfo
{
    uint16      shortAddr;
    byte        endPoint;
    uint8       exist;
    uint16       seqnb;
}AddrInfo_t;

AddrInfo_t TinyNode_AddrArr[TINY_ID_MAX];
AddrInfo_t PothoNode_AddrArr[PHOTO_ID_MAX];


afAddrType_t gResponseAddr;

#define CLUSTER_PHOTO_NODE  0x0001
#define CLUSTER_TINY_NODE   0x0002

#define TYPE_PHOTO 0x01
#define HDR_LENGTH 8
